package org.ohdsi.cohortcharacterization;

public interface Constants {
	interface Params {
		String RESULTS_DATABASE_SCHEMA = "results_database_schema";
		String TARGET_DATABASE_SCHEMA = "target_database_schema";
		String TEMP_DATABASE_SCHEMA = "temp_database_schema";
		String CDM_DATABASE_SCHEMA = "cdm_database_schema";
		String VOCABULARY_DATABASE_SCHEMA = "vocabulary_database_schema";
	}
}

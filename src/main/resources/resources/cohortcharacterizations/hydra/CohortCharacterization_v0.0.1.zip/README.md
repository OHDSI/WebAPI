SkeletonCohortCharacterization
================================

A Java and R package for generation Cohort Characterization in the Common Data Model

Features
========

- Takes a cohort characterization as input.
- Generates query in a Microsoft SQL Server Dialect

Technology
==========

SkeletonCohortCharacterization is an R package that wraps Java query generator.
